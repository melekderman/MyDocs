# CARRE Beamer Poster Template

48 x 36 in (121.92 x 91.44 cm) landscape `beamerposter` template, matched element-by-element
to the seven `CARRE-Poster-<UNIV>.pptx` files (colours, logo boxes, font sizes, positions).

## Compile

```bash
latexmk -pdf main.tex      # needs two passes (TikZ "remember picture"); Overleaf does this automatically
```

## Switch institution

One line in `main.tex`:

```tex
\posteruniversity{ND}   % ND, OSU, VU, NCSU, UCSD, SU, UCB
```

This sets, exactly as in the matching .pptx:

| | Header bar | Section headings | Results | Objective/Conclusions title bar (fill / border / text) | Lead-text bar (fill / border / text) | Logo box (x, y, w, h cm) |
|---|---|---|---|---|---|---|
| ND   | 0D0D0D | 172B48 | 172B48 | DEC992 / DEC992 / 172B48 | DEC992 / DEC992 / 172B48 | 93.36, 6.64, 24.29, 6.82 |
| OSU  | F1491C | F1491C | F1491C | F1491C / F1491C / FFFFFF | E7E6E6 / F1491C / 000000 | 95.36, 6.32, 23.27, 7.45 |
| VU   | 0D0D0D | 262626 | 262626 | D5BC7E / D5BC7E / FFFFFF | D5BC7E / D5BC7E / 262626 (Concl. 000000) | 92.39, 6.16, 25.26, 7.77 |
| NCSU | 0D0D0D | CC0100 | 262626 | CC0100 / CC0100 / FFFFFF | CC0100 / CC0100 / FFFFFF | 94.07, 4.31, 24.84, 11.96 |
| UCSD | 0D0D0D | 172B48 | 172B48 | C69214 / 172B48 / FFFFFF | 172B48 / 172B48 / FFFFFF | 92.43, 7.70, 25.22, 4.73 |
| SU   | 0D0D0D | 000000 | 172B48 | AA0000 / AA0000 / FFFFFF | AA0000 / AA0000 / FFFFFF | 96.06, 4.77, 21.59, 8.57 |
| UCB  | 0D0D0D | 002E70 | 172B48 | 002E70 / 002E70 / FFFFFF | 002E70 / 002E70 / FFFFFF | 96.06, 3.97, 21.59, 12.14 |

Shared: CARRE logo at (4.27, 3.76) 15.06 x 12.58 cm, title black 72 pt, authors 52.8 pt and
affiliation 43.2 pt in grey 757070, section rules 7 pt grey 757070 fading to white.

## Layout / commands

Columns are placed at the .pptx coordinates; content flows top-down inside each one.

- `posterleft` (x 3.01, w 33.90), `postercenter` (x 41.00, w 39.91), `posterright` (x 84.96, w 33.91)
- `\posterobjective{...}`, `\posterconclusions{...}` — two-band blocks
- `\postersection{Title}` — 60 pt heading + faded rule; `\posterresults` — 66 pt Results heading
- `\postertext{...}`, `\postersmall{...}` — 32 pt justified body text
- `\posterhighlight{Title}{Text}` is kept for backwards compatibility

The `\vspace` values in `main.tex` put every heading at its .pptx position for the placeholder
content; adjust them once real content is in.
